from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        # Retrieve data from the form
        business_type = request.form["business_type"]
        brand_about = request.form["brand_about"]
        brand_name = request.form["brand_name"]
        product_name = request.form["product_name"]
        favorite_color = request.form["favorite_color"]
        target_audience = request.form["target_audience"]
        style_preference = request.form["style_preference"]
        logos_examples = request.form["logos_examples"]
        symbols_included = request.form["symbols_included"]
        logo_use = request.form["logo_use"]
        deadline = request.form["deadline"]

        # You can process the form data here or save it to a database
        # For now, we will just print it
        print(f"Business Type: {business_type}")
        print(f"Brand About: {brand_about}")
        print(f"Brand Name: {brand_name}")
        print(f"Product Name: {product_name}")
        print(f"Favorite Color: {favorite_color}")
        print(f"Target Audience: {target_audience}")
        print(f"Style Preference: {style_preference}")
        print(f"Logos Examples: {logos_examples}")
        print(f"Symbols Included: {symbols_included}")
        print(f"Logo Use: {logo_use}")
        print(f"Deadline: {deadline}")
        
        return "Thank you for submitting your design requirements!"

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)



