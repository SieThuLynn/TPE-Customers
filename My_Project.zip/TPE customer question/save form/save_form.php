<?php
$servername = "localhost";
$username = "root"; // Change this to your database username
$password = "1234"; // Change this to your database password
$dbname = "$brand_name"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO customer_responses (business_type, brand_about, brand_name, product_name, favorite_color, target_audience, style_preference, logos_examples, symbols_included, logo_use, deadline) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssssss", $business_type, $brand_about, $brand_name, $product_name, $favorite_color, $target_audience, $style_preference, $logos_examples, $symbols_included, $logo_use, $deadline);

// Set parameters
$business_type = $_POST['business_type'];
$brand_about = $_POST['brand_about'];
$brand_name = $_POST['brand_name'];
$product_name = $_POST['product_name'];
$favorite_color = $_POST['favorite_color'];
target_audience = $_POST['target_audience'];
$style_preference = $_POST['style_preference'];
$logos_examples = $_POST['logos_examples'];
$symbols_included = $_POST['symbols_included'];
$logo_use = $_POST['logo_use'];
$deadline = $_POST['deadline'];

// Execute the statement
if ($stmt->execute()) {
    echo "Form submitted successfully!";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>
